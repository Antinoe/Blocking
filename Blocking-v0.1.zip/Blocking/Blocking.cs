using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ModLoader;


namespace Blocking
{
	public class Blocking : Mod
	{
		public static ModHotKey Block;
		
        public override void Load()
        {
            Block = RegisterHotKey("Block", "G");
        }
        
        public override void Unload()
        {
            Block = null;
        }
    }
}
