using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Terraria;
using Terraria.ModLoader;

namespace Blocking.Buffs
{
    public class Shield : ModBuff
    {
        public override void SetDefaults()
        {
            DisplayName.SetDefault("Shield Raised");
            Description.SetDefault("You are fortified.");
            Main.buffNoTimeDisplay[Type] = false;
            Main.debuff[Type] = false;
        }
        public override void Update(Player player, ref int buffIndex)
        {
			{
				player.velocity.X = player.velocity.X * 0.9f;
			}
        }
    }
}
