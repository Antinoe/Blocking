﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using ReLogic.Graphics;
using Terraria;
using Terraria.DataStructures;
using Terraria.GameInput;
using Terraria.ID;
using Terraria.ModLoader;
using Terraria.ModLoader.IO;

namespace Blocking
{
    public class BlockingPlayer : ModPlayer
    {	
		public bool block;
		
		public static BlockingPlayer ModPlayer(Player player)
		{
			return player.GetModPlayer<BlockingPlayer>();
		}
		
		public override void PostUpdateMiscEffects()
		{
			if (block)
			{
				player.noKnockback = true;
				player.longInvince = true;
				player.velocity.X *= 0.9f;
				player.delayUseItem = true;
				//player.statDefense += 10;
				player.statDefense = (int)(player.statDefense * 2f);
				//player.endurance = 1f - 0.1f * (1f - player.endurance);
				//player.endurance *= 2f;
			}
			if (!block)
			{
				player.velocity.X *= 1f; 
			}
			if (Blocking.Block.JustPressed)
			{
				{
					block = !block;
				}
			}
		}
    }
}
